﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HitPoint
{
    public partial class Form1 : Form
    {
        private List<Point> points = new List<Point>();
        private Bitmap srcBmp;
        private Bitmap maskBmp;
        private int radius = 10;
        private bool canDraw = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void LoadBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JPG Files(*.jpg;*.jpeg)|*.jpg;*.jpeg|BMP Files(*.bmp)|*.bmp|All Files(*.*)|*.*";
            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                Bitmap bmp = new Bitmap(ofd.FileName);
                //Image testImg = bmp;
                //Image testImg2 = new Bitmap(ofd.FileName);//父类对象可以用子类实例化
                //Bitmap testBmp2 = Image.FromFile(ofd.FileName);//子类对象不能用父类实例化
                //Bitmap testBmp = (Bitmap)testImg;
                if (bmp == null)
                {
                    MessageBox.Show("加载图片失败!", "错误");
                    return;
                }
                this.srcBmp = bmp;
                this.maskBmp = new Bitmap(bmp.Width, bmp.Height);
                this.maskBmp = brushBmpBlack(this.maskBmp, new Rectangle(0, 0, bmp.Width, bmp.Height));
                this.pictureBox1.Image = (Bitmap)srcBmp.Clone();//不然会同步改动
                ofd.Dispose();
            }
            string[] messages = ofd.FileName.Split('\\');
            int len = messages.Length;
            this.FileNameTxt.Text = messages[len - 1];
            this.points.Clear();//一定要清空之前的点
            this.NumLabel.Text = "0";
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (this.pictureBox1.Image ==null)
            {
                MessageBox.Show("尚未加载图片", "警告");
                return;
            }
            SaveFileDialog sfd = new SaveFileDialog();
            try
            {               
                string fullFileName = this.FileNameTxt.Text;
                string[] fileName = fullFileName.Split('.');
                sfd.FileName = fileName[0] + "_processed";
                sfd.Filter = "JPG Files(*.jpg;*.jpeg)|*.jpg;*.jpeg|BMP Files(*.bmp)|*.bmp|All Files(*.*)|*.*";
                if (sfd.ShowDialog() == DialogResult.OK)
                {                    
                    string path = sfd.FileName;
                    string[] pathStrs = path.Split('.');
                    if (pathStrs.Length > 2)
                    {
                        MessageBox.Show("保存路径中的文件夹或文件名称不能含有'.'","错误提示");
                        return;
                    }
                    this.maskBmp.Save(pathStrs[0] + "_mask.jpg");
                    this.pictureBox1.Image.Save(sfd.FileName);
                    MessageBox.Show("保存成功!", "提示");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("该文件被占用,无法替换","异常信息");
            }
            finally
            {
                sfd.Dispose();
            }
            
        }
        private Bitmap brushBmpBlack(Bitmap bmp, Rectangle rect)
        {
            Graphics g = Graphics.FromImage(bmp);
            SolidBrush blackBrush = new SolidBrush(Color.Black);
            g.FillRectangle(blackBrush, rect);
            return bmp;
        }
        private Bitmap changeBmpSize(Bitmap bmp, int afterWidth, int afterHeight)
        {
            Bitmap resBmp = new Bitmap(afterWidth,afterHeight);
            int width = bmp.Width;
            int height = bmp.Height;
            Graphics g = Graphics.FromImage(resBmp);
            g.DrawImage(bmp, new Rectangle(0, 0, afterWidth, afterHeight), 
                new Rectangle(0, 0, width, height), GraphicsUnit.Pixel);
            return resBmp;
        }
        //For look better
        private void NumLabel_Click(object sender, EventArgs e)
        {
            this.NumLabel.Focus();
        }
        //正式处理打点的程序
        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (!canDraw)
            {
                return;
            }
            if (e.Button == MouseButtons.Left)//左键
            {
                int x = e.X;
                int y = e.Y;
                double xd = (double)x;
                double yd = (double)y;
                bool exist = false;
                foreach (Point point in this.points)
                {                    
                    double px = (double)point.X;
                    double py = (double)point.Y;
                    double dist = Math.Sqrt((xd-px)*(xd-px)+(yd-py)*(yd-py));
                    if (dist / 2 < (double)radius)
                    {
                        exist = true;
                        break;
                    }
                }
                if (!exist && this.pictureBox1.Image != null)
                {
                    //graphics画在窗口上最大最小化后会失效,因为还原时窗体需要重绘，会覆盖之前的graphics图像，画在图片上不会失效
                    Image pImg = this.pictureBox1.Image;
                    Graphics gp = Graphics.FromImage(pImg);
                    SolidBrush blueBrush = new SolidBrush(Color.GreenYellow);
                    Rectangle rect = new Rectangle(x - radius, y - radius, 2 * radius, 2 * radius);
                    gp.FillEllipse(blueBrush, rect);
                    this.pictureBox1.Image = pImg;
                    this.points.Add(new Point(x, y));
                    this.NumLabel.Text = points.Count.ToString();
                    //给mask也加上点
                    Graphics gm = Graphics.FromImage(this.maskBmp);
                    gm.FillEllipse(blueBrush, rect);
                }         
            }
            else//右键
            {
                int x = e.X;
                int y = e.Y;
                double xd = (double)x;
                double yd = (double)y;
                foreach (Point point in this.points)
                {
                    double px = (double)point.X;
                    double py = (double)point.Y;
                    double dist = Math.Sqrt((xd - px) * (xd - px) + (yd - py) * (yd - py));
                    if (dist < (double)radius)
                    {
                        Image pImg = this.pictureBox1.Image;
                        Graphics gp = Graphics.FromImage(pImg);
                        Rectangle rect = new Rectangle(point.X-radius,point.Y-radius,2*radius,2*radius);
                        gp.DrawImage(srcBmp, rect, rect, GraphicsUnit.Pixel);
                        this.pictureBox1.Image = pImg;
                        this.points.Remove(point);
                        this.NumLabel.Text = this.points.Count.ToString();
                        //给mask也删除点
                        this.maskBmp = brushBmpBlack(this.maskBmp, rect);
                        break;
                    }
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
            {
                canDraw = false;
                this.panel1.AutoScroll = false;
                this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                this.pictureBox1.Width = this.panel1.Width;
                this.pictureBox1.Height = this.panel1.Height;
            }
            else
            {
                canDraw = true;
                this.panel1.AutoScroll = true;
                this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            }
        }
    }
}
